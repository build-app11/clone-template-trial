// ==============================|| OVERRIDES - CARD ACTIONS ||============================== //

export default function CardActions() {
  return {
    MuiCardActions: {
      styleOverrides: {
        root: {
          padding: '24px'
        }
      }
    }
  };
}
